# -*- coding: utf-8 -*-
"""
Created on Mon Jan 18 09:37:52 2021

@author: mguerder
"""


class Hull:

    def __init__(self):
        self.geometry = None
